package com.rhynsforge.keyforge

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textview.MaterialTextView
import android.widget.LinearLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = MaterialTextView(this).apply {
            text = "KeyForge AI Keyboard"
            textSize = 26f
        }

        val info = MaterialTextView(this).apply {
            text = "Enable KeyForge in Android keyboard settings, then select it as your keyboard."
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }

        val settings = MaterialButton(this).apply {
            text = "Open Keyboard Settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }

        root.addView(title)
        root.addView(info)
        root.addView(settings)
        setContentView(root)
    }
}
