package com.rhynsforge.keyforge

import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class KeyForgeInputMethodService : InputMethodService() {

    private lateinit var root: LinearLayout

    override fun onCreateInputView(): View {
        return buildKeyboard()
    }

    private fun buildKeyboard(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(6, 6, 6, 6)
            setBackgroundColor(Color.rgb(18, 18, 18))
        }

        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        tools.addView(toolButton("AI") { showAi() }, lp(0, 48, 1f))
        tools.addView(toolButton("📋") { pasteClipboard() }, lp(0, 48, 1f))
        tools.addView(toolButton("←") { sendKey(android.view.KeyEvent.KEYCODE_DEL) }, lp(0, 48, 1f))
        tools.addView(toolButton("↵") { sendEnter() }, lp(0, 48, 1f))

        root.addView(tools)

        addRow("QWERTYUIOP")
        addRow("ASDFGHJKL")
        addRow("ZXCVBNM")

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(key("ABC") { }, lp(0, 54, 1f))
        bottom.addView(key("SPACE") {
            currentInputConnection?.commitText(" ", 1)
        }, lp(0, 54, 3f))
        bottom.addView(key(".") {
            currentInputConnection?.commitText(".", 1)
        }, lp(0, 54, 1f))
        bottom.addView(key("⌫") {
            sendKey(android.view.KeyEvent.KEYCODE_DEL)
        }, lp(0, 54, 1f))
        root.addView(bottom)

        return root
    }

    private fun addRow(chars: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        for (c in chars) {
            row.addView(key(c.toString()) {
                currentInputConnection?.commitText(c.toString().lowercase(), 1)
            }, lp(0, 52, 1f))
        }
        root.addView(row)
    }

    private fun key(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            setOnClickListener { action() }
        }
    }

    private fun toolButton(label: String, action: () -> Unit): Button = key(label, action)

    private fun lp(w: Int, h: Int, weight: Float): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(w, h, weight).apply {
            setMargins(2, 2, 2, 2)
        }
    }

    private fun sendKey(code: Int) {
        currentInputConnection?.sendKeyEvent(
            android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, code)
        )
        currentInputConnection?.sendKeyEvent(
            android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, code)
        )
    }

    private fun sendEnter() {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        if (info != null && (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
            ic.performEditorAction(info.imeOptions and EditorInfo.IME_MASK_ACTION)
        } else {
            ic.commitText("
", 1)
        }
    }

    private fun pasteClipboard() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val clip = cm.primaryClip ?: return
        if (clip.itemCount > 0) {
            currentInputConnection?.commitText(clip.getItemAt(0).coerceToText(this), 1)
        }
    }

    private fun showAi() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.rgb(18, 18, 18))
        }

        val title = TextView(this).apply {
            text = "KeyForge AI"
            textSize = 20f
            setTextColor(Color.WHITE)
        }

        val prompt = android.widget.EditText(this).apply {
            hint = "Ask KeyForge to write something..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }

        val output = TextView(this).apply {
            text = "AI output will appear here."
            setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 12)
        }

        val generate = key("Generate") {
            output.text = "AI connection is ready for the next integration step."
        }

        val insert = key("Insert") {
            currentInputConnection?.commitText(output.text, 1)
        }

        val back = key("Back to keyboard") {
            setInputView(buildKeyboard())
        }

        panel.addView(title)
        panel.addView(prompt)
        panel.addView(generate)
        panel.addView(output)
        panel.addView(insert)
        panel.addView(back)

        val scroll = ScrollView(this)
        scroll.addView(panel)
        setInputView(scroll)
    }
}
