# KeyForge AI Keyboard

Native Android InputMethodService keyboard for KeyForge.

## Build

This project is built with Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35, and Java 17.

## Install

Build the debug APK, install it on Android, then open the KeyForge app and enable the keyboard in Android keyboard settings.

## Status

The native IME, QWERTY keyboard, clipboard button, AI panel placeholder, and settings launcher are included. The AI generation backend can be connected in a later step.
